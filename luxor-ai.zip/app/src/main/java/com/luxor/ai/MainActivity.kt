package com.luxor.ai

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private lateinit var web: WebView
    private val pool = Executors.newCachedThreadPool()
    private val conns = ConcurrentHashMap<String, HttpURLConnection>()
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var recognizer: SpeechRecognizer? = null
    private var voiceLang = "ru-RU"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val bg = Color.parseColor("#04050F")
        window.statusBarColor = bg
        window.navigationBarColor = bg

        web = WebView(this)
        web.setBackgroundColor(bg)
        setContentView(web)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false

        web.addJavascriptInterface(Bridge(), "Native")

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return true
                if (url.startsWith("file:")) return false
                openExternal(url)
                return true
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = filePathCallback
                return try {
                    val intent = fileChooserParams!!.createIntent()
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    startActivityForResult(intent, 7)
                    true
                } catch (e: Exception) {
                    fileCb?.onReceiveValue(null)
                    fileCb = null
                    false
                }
            }
        }

        web.loadUrl("file:///android_asset/index.html")
    }

    private fun openExternal(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось открыть ссылку", Toast.LENGTH_SHORT).show()
        }
    }

    private fun js(code: String) {
        runOnUiThread { web.evaluateJavascript(code, null) }
    }

    private fun q(s: String): String = JSONObject.quote(s)

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 7) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCb = null
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 11) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                beginVoice()
            } else {
                js("window.__voice('error','denied')")
            }
        }
    }

    private fun beginVoice() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            js("window.__voice('error','unavailable')")
            return
        }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { js("window.__voice('ready','')") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) { js("window.__voice('rms','" + rmsdB + "')") }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { js("window.__voice('error','" + error + "')") }
            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                js("window.__voice('final'," + q(t) + ")")
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                if (t.isNotEmpty()) js("window.__voice('partial'," + q(t) + ")")
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, voiceLang)
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        r.startListening(i)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.__back && window.__back()) ? 'true' : 'false'") { v ->
            if (v == null || !v.contains("true")) finish()
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        pool.shutdownNow()
        super.onDestroy()
    }

    inner class Bridge {

        @JavascriptInterface
        fun request(id: String, url: String, method: String, headers: String, body: String) {
            pool.execute {
                var status = 0
                var err = ""
                var carry = ""
                try {
                    val c = URL(url).openConnection() as HttpURLConnection
                    conns[id] = c
                    c.requestMethod = method
                    c.connectTimeout = 30000
                    c.readTimeout = 300000
                    c.instanceFollowRedirects = true
                    val h = JSONObject(headers)
                    val keys = h.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        c.setRequestProperty(k, h.getString(k))
                    }
                    if (method != "GET" && body.isNotEmpty()) {
                        c.doOutput = true
                        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                    }
                    status = c.responseCode
                    val stream = if (status >= 400) c.errorStream else c.inputStream
                    if (stream != null) {
                        val r = BufferedReader(InputStreamReader(stream, Charsets.UTF_8))
                        val buf = CharArray(4096)
                        while (true) {
                            val n = r.read(buf)
                            if (n < 0) break
                            var s = carry + String(buf, 0, n)
                            carry = ""
                            if (s.isNotEmpty() && Character.isHighSurrogate(s[s.length - 1])) {
                                carry = s.substring(s.length - 1)
                                s = s.substring(0, s.length - 1)
                            }
                            if (s.isNotEmpty()) js("window.__nc(" + q(id) + "," + q(s) + ")")
                        }
                    }
                } catch (e: Exception) {
                    err = e.message ?: e.toString()
                } finally {
                    conns.remove(id)?.disconnect()
                }
                js("window.__nd(" + q(id) + "," + status + "," + q(err) + ")")
            }
        }

        @JavascriptInterface
        fun cancel(id: String) {
            val c = conns[id]
            if (c != null) pool.execute { try { c.disconnect() } catch (e: Exception) {} }
        }

        @JavascriptInterface
        fun copy(text: String) {
            runOnUiThread {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("Luxor AI", text))
                Toast.makeText(this@MainActivity, "Скопировано", Toast.LENGTH_SHORT).show()
            }
        }

        @JavascriptInterface
        fun openUrl(url: String) {
            runOnUiThread { openExternal(url) }
        }

        @JavascriptInterface
        fun startVoice(lang: String) {
            runOnUiThread {
                voiceLang = lang
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 11)
                } else {
                    beginVoice()
                }
            }
        }

        @JavascriptInterface
        fun stopVoice() {
            runOnUiThread { recognizer?.stopListening() }
        }
    }
}
